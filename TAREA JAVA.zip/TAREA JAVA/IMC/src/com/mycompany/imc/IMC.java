/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.imc;

/**
 *
 * @author David
 */


import java.util.ArrayList;
import java.util.Scanner;


public class IMC {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        ArrayList<Persona> listaPersonas = new ArrayList<>();
        Calculo miCalculo = new Calculo();
        Asignacion miAsignacion = new Asignacion();
        int opcion = 0;

        System.out.println("=== SISTEMA DE BIENESTAR UNIVERSITARIO ===");

        while (opcion != 3) {
            System.out.println("\nMenu Principal:");
            System.out.println("1. Registrar paciente (Almacenamiento masivo)");
            System.out.println("2. Ver resultados y clasificacion");
            System.out.println("3. Salir");
            System.out.print("Elige una opcion: ");
            
            if (scanner.hasNextInt()) {
                opcion = scanner.nextInt();
                scanner.nextLine(); 
            } else {
                System.out.println("Por favor, ingresa un número válido.");
                scanner.nextLine();
                continue;
            }

            if (opcion == 1) {
                System.out.println("\n--- NUEVO REGISTRO ---");
                System.out.print("Nombre completo: ");
                String nombre = scanner.nextLine();
                System.out.print("Fecha nacimiento (DD/MM/AAAA): ");
                String fecha = scanner.nextLine();
                System.out.print("Peso (en kg, ej. 70.5): ");
                double peso = scanner.nextDouble();
                System.out.print("Estatura (en metros, ej. 1.75): ");
                double estatura = scanner.nextDouble();
                scanner.nextLine(); 
                System.out.print("Direccion: ");    
                String dir = scanner.nextLine();
                System.out.print("Telefono: ");
                String tel = scanner.nextLine();
                System.out.print("Correo electronico: ");
                String correo = scanner.nextLine();

                Persona p = new Persona(nombre, fecha, peso, estatura, dir, tel, correo);
                listaPersonas.add(p);
                System.out.println("Registro guardado con exito");

            } else if (opcion == 2) {
                System.out.println("\n--- RESULTADOS DE EVALUACION ---");
                if (listaPersonas.isEmpty()) {
                    System.out.println("Aun no hay registros en el sistema.");
                } else {
                    for (Persona p : listaPersonas) {
                        double imcResultado = miCalculo.hacerCalculo(p.getPeso(), p.getEstatura());
                        String categoria = miAsignacion.evaluarCategoria(imcResultado);
                        
                        System.out.println("Paciente: " + p.getNombreCompleto());
                        System.out.println("IMC Calculado: " + String.format("%.2f", imcResultado));
                        System.out.println("Clasificacion OMS: " + categoria);
                        System.out.println("---------------------------------");
                    }
                }
            } else if (opcion == 3) {
                System.out.println("Cerrando el sistema de Bienestar Universitario...");
            } else {
                System.out.println("Opción no valida.");
            }
        }
        scanner.close();
    }
}

