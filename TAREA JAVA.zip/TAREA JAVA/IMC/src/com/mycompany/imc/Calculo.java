/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.imc;

/**
 *
 * @author David
 */

public class Calculo {
    public double hacerCalculo(double peso, double estatura) {
        return peso / (estatura * estatura);
    }
}
