/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.imc;

/**
 *
 * @author David
 */

public class Persona {
    private String nombreCompleto;
    private String fechaNacimiento;
    private double peso;
    private double estatura;
    private String direccion;
    private String telefono;
    private String correoElectronico;

    public Persona(String nombreCompleto, String fechaNacimiento, double peso, double estatura, String direccion, String telefono, String correoElectronico) {
        this.nombreCompleto = nombreCompleto;
        this.fechaNacimiento = fechaNacimiento;
        this.peso = peso;
        this.estatura = estatura;
        this.direccion = direccion;
        this.telefono = telefono;
        this.correoElectronico = correoElectronico;
    }

    public double getPeso() { return peso; }
    public double getEstatura() { return estatura; }
    public String getNombreCompleto() { return nombreCompleto; }
}
